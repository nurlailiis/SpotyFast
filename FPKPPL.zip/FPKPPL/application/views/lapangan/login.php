<section class="product">
		<div style="margin: 100px"  class="container">
			<div class="row">
				<div class="col-md-4">
					<br>
					<h4>Sudah punya akun? Masuk disini</h4>
					<div class="login-box">						
						<?php echo form_open('lapangan/cek_login/'); ?>
							<p><input type="text" autofocus="" class="form-control" placeholder="username" name="username"></p>
							<p><input type="password" class="form-control" placeholder="password" name="password"></p>
							<p><input type="submit" value="Masuk" class="btn btn-default btn-login" name=""></p>
						</form>
					</div>
				</div>			
			</div>
		</div>
</section>
